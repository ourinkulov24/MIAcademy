<div>
    <?php echo $__env->make('livewire.user.buds.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section>
        <div class="container">
            <div class="row">
                <div class="col-8 offset-2 mt-2">
                    <?php if(session()->has('message-suc')): ?>
                        <div class="alert alert-success"><?php echo e(session('message-suc')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('message-dan')): ?>
                        <div class="alert alert-danger"><?php echo e(session('message-dan')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>




                    <div class="card">
                        <div class="card-header">
                            <h5>Budget | <button class="btn btn-primary text-white" data-toggle="modal" data-target="#buds"><i class="fa fa-user-plus fa-1x text-white"></i> Add budget</button></h5>
                        </div>
                        <div class="card-body">
                            <table class="border-0 table bg-white table-responsive-lg " width="100%" >
                                <thead class="text-primary">
                                <th>#</th>
                                <th>Name</th>
                                <th>Summa</th>
                                <th>Category</th>

                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $buds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($bud->id); ?></td>
                                        <td><?php echo e($bud->budname); ?></td>
                                        <td><?php echo e($bud->summa); ?></td>
                                        <td><?php echo e($bud->cat_name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH C:\xampp\htdocs\miacademy.local\resources\views/livewire/user/buds/buds.blade.php ENDPATH**/ ?>