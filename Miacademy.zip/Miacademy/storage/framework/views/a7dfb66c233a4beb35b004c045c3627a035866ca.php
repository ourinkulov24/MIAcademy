<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="card shadow-lg">
                    <div class="card-img">
                        <img src="<?php echo e(asset('storage/Steven_Hallam-slide.jpg')); ?>" alt="" style="width:100%;opacity: 0.6" >
                    </div>
                    <div class="card-footer text-center">
                        <h5><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="container">
                    <div class="row justify-content-center flex-row">

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="col-md-3">
                            <a href="<?php echo e(url('/users/joriynazorat')); ?>">
                                <div class="card shadow-lg">
                                    <div class="card-body text-center ca_cb">
                                        <div class="ca_card_icon">
                                            <i ><img src="<?php echo e(asset('storage/images/check-mark-svgrepo-com.svg')); ?>" width="64px" alt=""></i>
                                        </div>
                                        <div class="ca_card_title">
                                            JORIY NAZORAT YARATISH
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo e(url('/users/jnjurnal')); ?>">
                                <div class="card shadow-lg">
                                    <div class="card-body text-center ca_cb">
                                        <div class="ca_card_icon">
                                            <i ><img src="<?php echo e(asset('storage/images/studying-mark-svgrepo-com.svg')); ?>" width="64px"  alt="" ></i>
                                        </div>
                                        <div class="ca_card_title" class="mt-5">
                                            JN BAXOLASH
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo e(url('/users/useronjnjurnal')); ?>">
                                <div class="card shadow-lg">
                                    <div class="card-body text-center ca_cb">
                                        <div class="ca_card_icon">
                                            <i ><img src="<?php echo e(asset('storage/images/check-mark-correct-svgrepo-com.svg')); ?>" width="64px" alt=""></i>
                                        </div>
                                        <div class="ca_card_title">
                                            ON BAHOLASH
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>

                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\miacademy.local\resources\views/home.blade.php ENDPATH**/ ?>