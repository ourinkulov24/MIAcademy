<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Cat;

class Org extends Model
{
    use HasFactory;
    public $fillable = ['name','cats_id','boss'];

    public function cat(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Cat::class);
    }
}
