
<!-- Modal -->
<div wire:ignore.self class="modal fade" id="buds" tabindex="-1" role="dialog" aria-labelledby="buds" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="orgs">Add Budgets</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="">

                    <div class="form-group">
                        <label for="">Budgets</label>

                        <input type="text" class="form-control" name="name" wire:model="name">
                    </div>
                    <div class="form-group">
                        <label for="">Summa</label>
                        <input type="text" class="form-control" wire:model="summa">
                    </div>
                    <div class="form-group">
                        <label for="">Category</label>
                        <select name="" id="" wire:model="cats_id" class="form-control">
                            <option value="">Select category</option>
                            @foreach($cats as $cat)
                                <option value="{{$cat->id}}">{{$cat->name}}</option>
                            @endforeach
                        </select>

                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" wire:click.prevent="store()">Save</button>
            </div>
        </div>
    </div>
</div>
