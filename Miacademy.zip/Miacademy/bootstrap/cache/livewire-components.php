<?php return array (
  'user.buds.buds' => 'App\\Http\\Livewire\\User\\Buds\\Buds',
  'user.cats.cats' => 'App\\Http\\Livewire\\User\\Cats\\Cats',
  'user.orgs.orgs' => 'App\\Http\\Livewire\\User\\Orgs\\Orgs',
  'user.tenders.tenders' => 'App\\Http\\Livewire\\User\\Tenders\\Tenders',
  'user.tends.tends' => 'App\\Http\\Livewire\\User\\Tends\\Tends',
);