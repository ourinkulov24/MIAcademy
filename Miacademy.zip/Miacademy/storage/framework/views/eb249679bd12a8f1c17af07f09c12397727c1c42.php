<div>
    <?php echo $__env->make('livewire.user.tenders.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section>
        <div class="container-fluid ml-2">
            <div class="row">
                <div class="col-12  mt-2">
                    <?php if(session()->has('message-suc')): ?>
                        <div class="alert alert-success"><?php echo e(session('message-suc')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('message-dan')): ?>
                        <div class="alert alert-danger"><?php echo e(session('message-dan')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Tenders | <button class="btn btn-primary text-white" data-toggle="modal" data-target="#tenders"><i class="fa fa-user-plus fa-1x text-white"></i> Add tender</button></h5>
                        </div>
                        <div class="card-body">
                            <table class="border-0 table bg-white table-responsive-lg " width="100%" >
                                <thead class="text-primary">
                                <th>#</th>
                                <th>Tender</th>
                                <th>Budget</th>
                                <th>Customer</th>
                                <th>Participant</th>
                                <th>Head of dept.</th>
                                <th>Year</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tend_res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($tend->id); ?></td>
                                        <td><?php echo e($tend->tedname); ?></td>
                                        <td><?php echo e($tend->tends_summa); ?></td>
                                        <td><?php echo e($tend->cat_name); ?></td>
                                        <td><?php echo e($tend->org_name); ?></td>
                                        <td><?php echo e($tend->boss); ?></td>

                                        <td><?php echo e($tend->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH C:\xampp\htdocs\miacademy.local\resources\views/livewire/user/tenders/tenders.blade.php ENDPATH**/ ?>