<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tend extends Model
{
    use HasFactory;
    protected $fillable = ['tedname','cats_id','summa','buds_id','start_date','end_date','comment'];
}
