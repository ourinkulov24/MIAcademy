<?php

namespace App\Http\Livewire\User\Tenders;

use App\Models\Bud;
use App\Models\Cat;
use App\Models\Org;
use App\Models\Tender;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class Tenders extends Component
{
    public $tend_id,$cats_id,$buds_id,$stat_id,$comment,$org_id;
    public function render()
    {
        $cats = Cat::all();
        $buds = Bud::all();
        $tends = DB::table('v_tends')->get();
        $orgs = Org::all();
        $tend_res = DB::table('v_tender_result')->get();
        return view('livewire.user.tenders.tenders',compact('cats','buds','tends','orgs','tend_res'))->extends('layouts.app');
    }
    public function store()
    {
        if (
            Tender::create(
                [
                    'tend_id'=>$this->tend_id,
                    'cats_id'=>$this->cats_id,
                    'org_id'=>$this->org_id,
                    'buds_id'=>$this->buds_id,
                    'status'=>$this->stat_id,
                    'comment'=>$this->comment
                ]
            )
        )
        {
            session()->flash('message-suc','Qo\'shildi');
            $this->resetInput();
            $this->emit('catCreated');
        }
        else
        {
            session()->flash('message-dan','Xatolik mavjud Qaytadan kiriting');
            $this->resetInput();

        }

    }
    public function resetInput()
    {
        $this->tend_id = '';
        $this->cats_id = '';
        $this->org_id = '';
        $this->buds_id = '';
        $this->stat_id = '';
        $this->comment = '';
    }

}
