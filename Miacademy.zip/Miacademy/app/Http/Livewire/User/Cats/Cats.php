<?php

namespace App\Http\Livewire\User\Cats;

use App\Models\Cat;
use Livewire\Component;

class Cats extends Component
{
    public $name;
    public function render()
    {
        $cats = Cat::all();
        return view('livewire.user.cats.cats',compact('cats'))->extends('layouts.app');
    }
    public function store()
    {
        if (
            Cat::create([
                'name'=>$this->name
            ])
        )
            {
            session()->flash('message-suc','Qo\'shildi');
            $this->resetInput();
            $this->emit('catCreated');
            }
            else
             {
            session()->flash('message-dan','Xatolik mavjud Qaytadan kiriting');
            $this->resetInput();

             }

    }

    public function resetInput(){
        $this->name = '';
    }
}
