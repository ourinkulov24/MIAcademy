<div>
    @include('livewire.user.orgs.create')
    {{--    @include('livewire.admin.fans.update')--}}
    <section>
        <div class="container">
            <div class="row">
                <div class="col-8 offset-2 mt-2">
                    @if(session()->has('message-suc'))
                        <div class="alert alert-success">{{session('message-suc')}}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                    @if(session()->has('message-dan'))
                        <div class="alert alert-danger">{{session('message-dan')}}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif




                    <div class="card">
                        <div class="card-header">
                            <h5>Organizations | <button class="btn btn-primary text-white" data-toggle="modal" data-target="#orgs"><i class="fa fa-user-plus fa-1x text-white"></i> Add organizations</button></h5>
                        </div>
                        <div class="card-body">
                            <table class="border-0 table bg-white table-responsive-lg " width="100%" >
                                <thead class="text-primary">
                                <th>#</th>
                                <th>Name</th>
                                <th>Boss</th>
                                <th>Category</th>

                                </thead>
                                <tbody>
                                @foreach($orgs as $org)
                                    <tr>
                                        <td>{{$org->id}}</td>
                                        <td>{{$org->name}}</td>
                                        <td>{{$org->boss}}</td>
                                        <td>{{$org->cat_name}}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
</div>
