<div>
    @include('livewire.user.tends.create')
    {{--    @include('livewire.admin.fans.update')--}}
    <section>
        <div class="container-fluid ml-2">
            <div class="row">
                <div class="col-12  mt-2">
                    @if(session()->has('message-suc'))
                        <div class="alert alert-success">{{session('message-suc')}}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                    @if(session()->has('message-dan'))
                        <div class="alert alert-danger">{{session('message-dan')}}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif




                    <div class="card">
                        <div class="card-header">
                            <h5>Tenders | <button class="btn btn-primary text-white" data-toggle="modal" data-target="#teds"><i class="fa fa-user-plus fa-1x text-white"></i> Add tender</button></h5>
                        </div>
                        <div class="card-body">
                            <table class="border-0 table bg-white table-responsive-lg " width="100%" >
                                <thead class="text-primary">
                                <th>#</th>
                                <th>Name</th>
                                <th>Summa</th>
                                <th>Category</th>
                                <th>Budjet</th>
                                <th>Start date</th>
                                <th>End date</th>
                                <th>Description</th>

                                </thead>
                                <tbody>
                                @foreach($tends as $tend)
                                    <tr>
                                        <td>{{$tend->id}}</td>
                                        <td>{{$tend->tedname}}</td>
                                        <td>{{$tend->summa}}</td>
                                        <td>{{$tend->cat_name}}</td>
                                        <td>{{$tend->budname}}</td>
                                        <td>{{$tend->start_date}}</td>
                                        <td>{{$tend->end_date}}</td>
                                        <td>{{$tend->comment}}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
</div>
