<div>
    <?php echo $__env->make('livewire.user.tends.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section>
        <div class="container-fluid ml-2">
            <div class="row">
                <div class="col-12  mt-2">
                    <?php if(session()->has('message-suc')): ?>
                        <div class="alert alert-success"><?php echo e(session('message-suc')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('message-dan')): ?>
                        <div class="alert alert-danger"><?php echo e(session('message-dan')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>




                    <div class="card">
                        <div class="card-header">
                            <h5>Tenders | <button class="btn btn-primary text-white" data-toggle="modal" data-target="#teds"><i class="fa fa-user-plus fa-1x text-white"></i> Add tender</button></h5>
                        </div>
                        <div class="card-body">
                            <table class="border-0 table bg-white table-responsive-lg " width="100%" >
                                <thead class="text-primary">
                                <th>#</th>
                                <th>Name</th>
                                <th>Summa</th>
                                <th>Category</th>
                                <th>Budjet</th>
                                <th>Start date</th>
                                <th>End date</th>
                                <th>Description</th>

                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($tend->id); ?></td>
                                        <td><?php echo e($tend->tedname); ?></td>
                                        <td><?php echo e($tend->summa); ?></td>
                                        <td><?php echo e($tend->cat_name); ?></td>
                                        <td><?php echo e($tend->budname); ?></td>
                                        <td><?php echo e($tend->start_date); ?></td>
                                        <td><?php echo e($tend->end_date); ?></td>
                                        <td><?php echo e($tend->comment); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH C:\xampp\htdocs\miacademy.local\resources\views/livewire/user/tends/tends.blade.php ENDPATH**/ ?>