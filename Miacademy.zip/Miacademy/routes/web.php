<?php

use Illuminate\Support\Facades\Route;
use App\Http\Livewire\User\Cats\Cats;
use App\Http\Livewire\User\Orgs\Orgs;
use App\Http\Livewire\User\Buds\Buds;
use App\Http\Livewire\User\Tends\Tends;
use App\Http\Livewire\User\Tenders\Tenders;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/admin', function () {
    return view('admin.index');
});
Route::get('/cats',Cats::class);
Route::get('/orgs',Orgs::class);
Route::get('/buds',Buds::class);
Route::get('/tends',Tends::class);
Route::get('/tenders',Tenders::class);

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
