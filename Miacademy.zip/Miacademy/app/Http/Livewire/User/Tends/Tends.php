<?php

namespace App\Http\Livewire\User\Tends;

use App\Models\Bud;
use App\Models\Cat;
use App\Models\Tend;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class Tends extends Component
{
    public $tedname,$summa,$buds_id,$cats_id,$start_date,$end_date,$comment;
    public function render()
    {
        $cats = Cat::all();
        $buds = Bud::all();
        $tends = DB::table('v_tends')->get();
        return view('livewire.user.tends.tends',compact('cats','buds','tends'))->extends('layouts.app');
    }
    public function store()
    {
        if (
            Tend::create([
                'tedname'=>$this->tedname,
                'summa'=>$this->summa,
                'buds_id'=>$this->buds_id,
                'cats_id'=>$this->cats_id,
                'start_date'=>$this->start_date,
                'end_date'=>$this->end_date,
                'comment'=>$this->comment,
            ])
        )
        {
            session()->flash('message-suc','Qo\'shildi');
            $this->resetInput();
            $this->emit('catCreated');
        }
        else
        {
            session()->flash('message-dan','Xatolik mavjud Qaytadan kiriting');
            $this->resetInput();

        }

    }

    public function resetInput(){
        $this->tedname = '';
        $this->summa = '';
        $this->cats_id = '';
        $this->buds_id = '';
    }
}
