
<!-- Modal -->
<div wire:ignore.self class="modal fade" id="tenders" tabindex="-1" role="dialog" aria-labelledby="tenders" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tenders">Add Tender</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="">









                    <div class="form-group">
                        <label for="">Tender</label>
                        <select name="" id="" wire:model="tend_id" class="form-control">
                            <option value="">Select section</option>
                            <?php $__currentLoopData = $tends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tend->id); ?>"><?php echo e($tend->tedname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                    <div class="form-group">
                        <label for="">Category</label>
                        <select name="" id="" wire:model="cats_id" class="form-control">
                            <option value="">Select category</option>
                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Organization</label>
                        <select name="" id="" wire:model="org_id" class="form-control">
                            <option value="">Select budget</option>
                            <?php $__currentLoopData = $orgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($org->id); ?>"><?php echo e($org->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Status</label>
                        <select name="" id="" wire:model="stat_id" class="form-control">
                            <option value="">Select category</option>
                            <option value="1">Winner</option>
                            <option value="2">Lost</option>

                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Budget</label>
                        <select name="" id="" wire:model="buds_id" class="form-control">
                            <option value="">Select budget</option>
                            <?php $__currentLoopData = $buds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bud->id); ?>"><?php echo e($bud->budname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>













                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" wire:click.prevent="store()">Save</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\miacademy.local\resources\views/livewire/user/tenders/create.blade.php ENDPATH**/ ?>