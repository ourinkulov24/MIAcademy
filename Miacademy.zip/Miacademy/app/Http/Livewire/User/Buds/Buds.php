<?php

namespace App\Http\Livewire\User\Buds;

use App\Models\Bud;
use App\Models\Cat;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class Buds extends Component
{
    public $name,$summa,$cats_id;
    public function render()
    {
        $cats = Cat::all();
        $buds = DB::table('v_buds')->get();

        return view('livewire.user.buds.buds',compact('cats','buds'))->extends('layouts.app');
    }
    public function store()
    {
        if (
            Bud::create([
                'budname'=>$this->name,
                'summa'=>$this->summa,
                'cats_id'=>$this->cats_id
            ])
        )
        {
            session()->flash('message-suc','Qo\'shildi');
            $this->resetInput();
            $this->emit('catCreated');
        }
        else
        {
            session()->flash('message-dan','Xatolik mavjud Qaytadan kiriting');
            $this->resetInput();

        }

    }

    public function resetInput(){
        $this->name = '';
        $this->cats_id = '';
        $this->summa = '';
    }
}
